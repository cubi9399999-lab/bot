import React from 'react'
import RequiredPage from '.'

export { generateMetadata } from './generateMetadata';

const page = () => {

    return (
        <RequiredPage />
    )
}

export default page
