import React from 'react'
import ReCapcha from '.'

export { generateMetadata } from './generateMetadata';

const page = () => {

    return (
        <ReCapcha />
    )
}

export default page
